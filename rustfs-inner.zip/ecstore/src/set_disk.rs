use std::vec;

use crate::{
    disk::{error::DiskError, DiskStore, RUSTFS_META_MULTIPART_BUCKET, RUSTFS_META_TMP_BUCKET},
    disk::{DeleteOptions, ReadMultipleReq, ReadMultipleResp, ReadOptions, RenameDataResp},
    erasure::Erasure,
    error::{Error, Result},
    store_api::{
        BucketInfo, BucketOptions, CompletePart, FileInfo, GetObjectReader, HTTPRangeSpec, MakeBucketOptions,
        MultipartUploadResult, ObjectInfo, ObjectOptions, ObjectPartInfo, PartInfo, PutObjReader, StorageAPI,
    },
    store_init::ErasureError,
    utils::crypto::{base64_decode, base64_encode, hex, sha256},
};
use futures::future::join_all;
use http::HeaderMap;
use s3s::dto::StreamingBlob;
use time::OffsetDateTime;
use tokio::io::DuplexStream;

use tracing::{debug, error, warn};
use uuid::Uuid;

#[derive(Debug, Clone)]
pub struct SetDisks {
    pub disks: Vec<Option<DiskStore>>,
    pub set_drive_count: usize,
    pub parity_count: usize,
    pub set_index: usize,
    pub pool_index: usize,
}

impl SetDisks {
    fn default_write_quorum(&self) -> usize {
        let mut data_count = self.set_drive_count - self.parity_count;
        if data_count == self.parity_count {
            data_count += 1
        }

        data_count
    }
    async fn rename_data(
        disks: &[Option<DiskStore>],
        src_bucket: &str,
        src_object: &str,
        file_infos: &[FileInfo],
        dst_bucket: &str,
        dst_object: &str,
        // write_quorum: usize,
    ) -> (Vec<Option<RenameDataResp>>, Vec<Option<Error>>) {
        let mut futures = Vec::with_capacity(disks.len());

        let mut ress = Vec::with_capacity(disks.len());
        let mut errors = Vec::with_capacity(disks.len());

        for (i, disk) in disks.iter().enumerate() {
            if disk.is_none() {
                ress.push(None);
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }
            let disk = disk.as_ref().unwrap();
            let mut file_info = file_infos[i].clone();

            if file_info.erasure.index == 0 {
                file_info.erasure.index = i + 1;
            }

            futures.push(disk.rename_data(src_bucket, src_object, file_info, dst_bucket, dst_object))
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(res) => {
                    ress.push(Some(res));
                    errors.push(None);
                }
                Err(e) => {
                    ress.push(None);
                    errors.push(Some(e));
                }
            }
        }
        (ress, errors)
    }

    #[allow(dead_code)]
    async fn commit_rename_data_dir(
        &self,
        disks: &[Option<DiskStore>],
        bucket: &str,
        object: &str,
        data_dir: &str,
    ) -> Vec<Option<Error>> {
        let file_path = format!("{}/{}", object, data_dir);

        let mut futures = Vec::with_capacity(disks.len());
        let mut errors = Vec::with_capacity(disks.len());

        for disk in disks.iter() {
            if disk.is_none() {
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }

            let disk = disk.as_ref().unwrap();
            futures.push(disk.delete(
                bucket,
                &file_path,
                DeleteOptions {
                    recursive: true,
                    ..Default::default()
                },
            ));
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(_) => {
                    errors.push(None);
                }
                Err(e) => {
                    errors.push(Some(e));
                }
            }
        }

        errors
    }

    async fn rename_part(
        disks: &[Option<DiskStore>],
        src_bucket: &str,
        src_object: &str,
        dst_bucket: &str,
        dst_object: &str,
    ) -> Vec<Option<Error>> {
        let mut futures = Vec::with_capacity(disks.len());

        let mut errors = Vec::with_capacity(disks.len());

        for disk in disks.iter() {
            if disk.is_none() {
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }
            let disk = disk.as_ref().unwrap();
            futures.push(disk.rename_file(src_bucket, src_object, dst_bucket, dst_object))
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(_) => {
                    errors.push(None);
                }
                Err(e) => {
                    errors.push(Some(e));
                }
            }
        }
        errors
    }

    async fn write_all(disks: &[Option<DiskStore>], bucket: &str, object: &str, buff: Vec<u8>) -> Vec<Option<Error>> {
        let mut futures = Vec::with_capacity(disks.len());

        let mut errors = Vec::with_capacity(disks.len());

        for disk in disks.iter() {
            if disk.is_none() {
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }
            let disk = disk.as_ref().unwrap();
            futures.push(disk.write_all(bucket, object, buff.clone()));
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(_) => {
                    errors.push(None);
                }
                Err(e) => {
                    errors.push(Some(e));
                }
            }
        }
        errors
    }

    async fn write_unique_file_info(
        disks: &[Option<DiskStore>],
        org_bucket: &str,
        bucket: &str,
        prefix: &str,
        files: &[FileInfo],
        // write_quorum: usize,
    ) -> Vec<Option<Error>> {
        let mut futures = Vec::with_capacity(disks.len());
        let mut errors = Vec::with_capacity(disks.len());

        for (i, disk) in disks.iter().enumerate() {
            if disk.is_none() {
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }

            let disk = disk.as_ref().unwrap();
            let mut file_info = files[i].clone();
            file_info.erasure.index = i + 1;
            futures.push(disk.write_metadata(org_bucket, bucket, prefix, file_info));
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(_) => {
                    errors.push(None);
                }
                Err(e) => {
                    errors.push(Some(e));
                }
            }
        }
        errors
    }

    fn get_upload_id_dir(bucket: &str, object: &str, upload_id: &str) -> String {
        let upload_uuid = match base64_decode(upload_id.as_bytes()) {
            Ok(res) => {
                let decoded_str = String::from_utf8(res).expect("Failed to convert decoded bytes to a UTF-8 string");
                let parts: Vec<&str> = decoded_str.splitn(2, '.').collect();
                if parts.len() == 2 {
                    parts[1].to_string()
                } else {
                    upload_id.to_string()
                }
            }
            Err(_) => upload_id.to_string(),
        };

        format!("{}/{}", Self::get_multipart_sha_dir(bucket, object), upload_uuid)
    }

    fn get_multipart_sha_dir(bucket: &str, object: &str) -> String {
        let path = format!("{}/{}", bucket, object);
        hex(sha256(path.as_bytes()).as_ref())
    }

    async fn check_upload_id_exists(
        &self,
        bucket: &str,
        object: &str,
        upload_id: &str,
        _write: bool,
    ) -> Result<(FileInfo, Vec<FileInfo>)> {
        let upload_id_path = Self::get_upload_id_dir(bucket, object, upload_id);
        let disks = self.disks.clone();

        let (files, _errs) =
            Self::read_all_fileinfo(&disks, bucket, RUSTFS_META_MULTIPART_BUCKET, &upload_id_path, Uuid::nil(), false, false)
                .await;

        //TODO: reduceWriteQuorumErrs

        let fi = Self::pick_valid_fileinfo(&files);

        Ok((fi, files))
    }

    fn pick_valid_fileinfo(files: &[FileInfo]) -> FileInfo {
        // TODO: quorun check

        files
            .iter()
            .filter_map(|v| v.is_valid().then_some(v.clone()))
            .next()
            .unwrap_or_default()
    }

    async fn read_all_fileinfo(
        disks: &[Option<DiskStore>],
        org_bucket: &str,
        bucket: &str,
        object: &str,
        version_id: Uuid,
        read_data: bool,
        healing: bool,
    ) -> (Vec<FileInfo>, Vec<Option<Error>>) {
        let mut futures = Vec::with_capacity(disks.len());
        let mut ress = Vec::with_capacity(disks.len());
        let mut errors = Vec::with_capacity(disks.len());

        for disk in disks.iter() {
            if disk.is_none() {
                ress.push(FileInfo::default());
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }

            let disk = disk.as_ref().unwrap();
            let opts = ReadOptions { read_data, healing };
            futures.push(async move {
                disk.read_version(org_bucket, bucket, object, version_id.to_string().as_str(), &opts)
                    .await
            })
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(res) => {
                    ress.push(res);
                    errors.push(None);
                }
                Err(e) => {
                    ress.push(FileInfo::default());
                    errors.push(Some(e));
                }
            }
        }
        (ress, errors)
    }

    async fn read_multiple_files(disks: &[Option<DiskStore>], req: ReadMultipleReq, read_quorum: usize) -> Vec<ReadMultipleResp> {
        let mut futures = Vec::with_capacity(disks.len());
        let mut ress = Vec::with_capacity(disks.len());
        let mut errors = Vec::with_capacity(disks.len());

        for disk in disks.iter() {
            if disk.is_none() {
                ress.push(None);
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }

            let disk = disk.as_ref().unwrap();
            let req = req.clone();
            futures.push(disk.read_multiple(req));
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(res) => {
                    ress.push(Some(res));
                    errors.push(None);
                }
                Err(e) => {
                    ress.push(None);
                    errors.push(Some(e));
                }
            }
        }

        // debug!("ReadMultipleResp ress {:?}", ress);
        // debug!("ReadMultipleResp errors {:?}", errors);

        let mut ret = Vec::with_capacity(req.files.len());

        for want in req.files.iter() {
            let mut quorum = 0;

            let mut get_res = ReadMultipleResp::default();

            for res in ress.iter() {
                if res.is_none() {
                    continue;
                }

                let disk_res = res.as_ref().unwrap();

                for resp in disk_res.iter() {
                    if !resp.error.is_empty() || !resp.exists {
                        continue;
                    }

                    if &resp.file != want || resp.bucket != req.bucket || resp.prefix != req.prefix {
                        continue;
                    }
                    quorum += 1;

                    if get_res.mod_time > resp.mod_time || get_res.data.len() > resp.data.len() {
                        continue;
                    }

                    get_res = resp.clone();
                }
            }

            if quorum < read_quorum {
                // debug!("quorum < read_quorum: {} < {}", quorum, read_quorum);
                get_res.exists = false;
                get_res.error = ErasureError::ErasureReadQuorum.to_string();
                get_res.data = Vec::new();
            }

            ret.push(get_res);
        }

        // log err

        ret
    }

    async fn remove_object_part(
        &self,
        bucket: &str,
        object: &str,
        upload_id: &str,
        data_dir: &str,
        part_num: usize,
    ) -> Result<()> {
        let upload_id_path = Self::get_upload_id_dir(bucket, object, upload_id);
        let disks = self.disks.clone();
        // let disks = Self::shuffle_disks(&disks, &fi.erasure.distribution);

        let file_path = format!("{}/{}/part.{}", upload_id_path, data_dir, part_num);

        let mut futures = Vec::with_capacity(disks.len());
        let mut errors = Vec::with_capacity(disks.len());

        for disk in disks.iter() {
            if disk.is_none() {
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }

            let disk = disk.as_ref().unwrap();
            let file_path = file_path.clone();
            let meta_file_path = format!("{}.meta", file_path);

            futures.push(async move {
                disk.delete(RUSTFS_META_MULTIPART_BUCKET, &file_path, DeleteOptions::default())
                    .await?;
                disk.delete(RUSTFS_META_MULTIPART_BUCKET, &meta_file_path, DeleteOptions::default())
                    .await
            });
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(_) => {
                    errors.push(None);
                }
                Err(e) => {
                    errors.push(Some(e));
                }
            }
        }

        Ok(())
    }
    async fn remove_part_meta(&self, bucket: &str, object: &str, upload_id: &str, data_dir: &str, part_num: usize) -> Result<()> {
        let upload_id_path = Self::get_upload_id_dir(bucket, object, upload_id);
        let disks = self.disks.clone();
        // let disks = Self::shuffle_disks(&disks, &fi.erasure.distribution);

        let file_path = format!("{}/{}/part.{}.meta", upload_id_path, data_dir, part_num);

        let mut futures = Vec::with_capacity(disks.len());
        let mut errors = Vec::with_capacity(disks.len());

        for disk in disks.iter() {
            if disk.is_none() {
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }

            let disk = disk.as_ref().unwrap();
            futures.push(disk.delete(RUSTFS_META_MULTIPART_BUCKET, &file_path, DeleteOptions::default()));
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(_) => {
                    errors.push(None);
                }
                Err(e) => {
                    errors.push(Some(e));
                }
            }
        }

        Ok(())
    }

    // #[tracing::instrument(skip(self))]
    async fn delete_all(&self, bucket: &str, prefix: &str) -> Result<()> {
        let disks = self.disks.clone();

        let mut futures = Vec::with_capacity(disks.len());
        let mut errors = Vec::with_capacity(disks.len());

        for disk in disks.iter() {
            if disk.is_none() {
                errors.push(Some(Error::new(DiskError::DiskNotFound)));
                continue;
            }

            let disk = disk.as_ref().unwrap();
            futures.push(disk.delete(
                bucket,
                prefix,
                DeleteOptions {
                    recursive: true,
                    ..Default::default()
                },
            ));
        }

        let results = join_all(futures).await;
        for result in results {
            match result {
                Ok(_) => {
                    errors.push(None);
                }
                Err(e) => {
                    errors.push(Some(e));
                }
            }
        }

        error!("delete_all errs {:?}", &errors);

        Ok(())
    }

    // 打乱顺序
    fn shuffle_disks_and_parts_metadata_by_index(
        disks: &[Option<DiskStore>],
        parts_metadata: &[FileInfo],
        fi: &FileInfo,
    ) -> (Vec<Option<DiskStore>>, Vec<FileInfo>) {
        let mut shuffled_disks = vec![None; disks.len()];
        let mut shuffled_parts_metadata = vec![FileInfo::default(); parts_metadata.len()];
        let distribution = &fi.erasure.distribution;

        let mut inconsistent = 0;
        for (k, v) in parts_metadata.iter().enumerate() {
            if disks[k].is_none() {
                inconsistent += 1;
                continue;
            }

            if !v.is_valid() {
                inconsistent += 1;
                continue;
            }

            if distribution[k] != v.erasure.index {
                inconsistent += 1;
                continue;
            }

            let block_idx = distribution[k];
            shuffled_parts_metadata[block_idx - 1] = parts_metadata[k].clone();
            shuffled_disks[block_idx - 1] = disks[k].clone();
        }

        if inconsistent < fi.erasure.parity_blocks {
            return (shuffled_disks, shuffled_parts_metadata);
        }

        Self::shuffle_disks_and_parts_metadata(disks, parts_metadata, fi)
    }

    // 打乱顺序
    fn shuffle_disks_and_parts_metadata(
        disks: &[Option<DiskStore>],
        parts_metadata: &[FileInfo],
        fi: &FileInfo,
    ) -> (Vec<Option<DiskStore>>, Vec<FileInfo>) {
        let init = fi.mod_time.is_none();

        let mut shuffled_disks = vec![None; disks.len()];
        let mut shuffled_parts_metadata = vec![FileInfo::default(); parts_metadata.len()];
        let distribution = &fi.erasure.distribution;

        for (k, v) in disks.iter().enumerate() {
            if v.is_none() {
                continue;
            }

            if !init && !parts_metadata[k].is_valid() {
                continue;
            }

            // if !init && fi.xlv1 != parts_metadata[k].xlv1 {
            //     continue;
            // }

            let block_idx = distribution[k];
            shuffled_parts_metadata[block_idx - 1] = parts_metadata[k].clone();
            shuffled_disks[block_idx - 1] = disks[k].clone();
        }

        (shuffled_disks, shuffled_parts_metadata)
    }

    // shuffle_disks TODO: use origin value
    fn shuffle_disks(disks: &[Option<DiskStore>], distribution: &[usize]) -> Vec<Option<DiskStore>> {
        if distribution.is_empty() {
            return disks.to_vec();
        }

        let mut shuffled_disks = vec![None; disks.len()];

        for (i, v) in disks.iter().enumerate() {
            let idx = distribution[i];
            shuffled_disks[idx - 1] = v.clone();
        }

        shuffled_disks
    }

    async fn get_object_fileinfo(
        &self,
        bucket: &str,
        object: &str,
        _opts: &ObjectOptions,
        _read_data: bool,
    ) -> Result<(FileInfo, Vec<FileInfo>)> {
        let disks = self.disks.clone();
        let (files, errs) = Self::read_all_fileinfo(&disks, "", bucket, object, Uuid::nil(), false, false).await;
        // debug!("get_object_fileinfo files {:?}", &files);
        warn!("get_object_fileinfo errs {:?}", &errs);

        let fi = Self::pick_valid_fileinfo(&files);

        debug!("get_object_fileinfo pick fi {:?}", &fi);

        Ok((fi, files))
    }

    async fn get_object_with_fileinfo(
        // &self,
        bucket: &str,
        object: &str,
        offset: i64,
        length: i64,
        writer: &mut DuplexStream,
        fi: FileInfo,
        files: Vec<FileInfo>,
        disks: &Vec<Option<DiskStore>>,
    ) -> Result<()> {
        debug!("get_object_with_fileinfo fi {:?}", &fi);

        let (disks, files) = Self::shuffle_disks_and_parts_metadata_by_index(disks, &files, &fi);

        let total_size = fi.size as i64;

        let length = {
            if length < 0 {
                total_size - offset
            } else {
                length
            }
        };

        if offset > total_size || offset + length > total_size {
            return Err(Error::msg("offset out of range"));
        }

        let (part_index, mut part_offset) = fi.to_part_offset(offset)?;

        // debug!(
        //     "get_object_with_fileinfo start offset:{}, part_index:{},part_offset:{}",
        //     offset, part_index, part_offset
        // );

        let mut end_offset = offset;
        if length > 0 {
            end_offset += length - 1
        }

        let (last_part_index, _) = fi.to_part_offset(end_offset)?;

        // debug!(
        //     "get_object_with_fileinfo end offset:{}, part_index:{},part_offset:{}",
        //     end_offset, last_part_index, 0
        // );

        let erasure = Erasure::new(fi.erasure.data_blocks, fi.erasure.parity_blocks, fi.erasure.block_size);

        let mut total_readed: i64 = 0;
        for i in part_index..=last_part_index {
            if total_readed == length {
                break;
            }

            let part_number = fi.parts[i].number;
            let part_size = fi.parts[i].size;
            let mut part_length = part_size - part_offset as usize;
            if part_length > (length - total_readed) as usize {
                part_length = (length - total_readed) as usize
            }

            let mut readers = Vec::with_capacity(disks.len());
            for (idx, disk) in disks.iter().enumerate() {
                let disk = disk.as_ref().unwrap().clone();
                let part_path = format!("{}/{}/part.{}", object, files[idx].data_dir, part_number);

                debug!("read part_path {}", &part_path);

                let reader = match disk.read_file(bucket, part_path.as_str()).await {
                    Ok(r) => Some(r),
                    Err(_) => None,
                };

                readers.push(reader);
            }

            // debug!(
            //     "read part {} part_offset {},part_length {},part_size {}  ",
            //     part_number, part_offset, part_length, part_size
            // );
            let _n = erasure
                .decode(writer, readers, part_offset as usize, part_length, part_size)
                .await?;

            // debug!("ec decode {} writed size {}", part_number, n);

            total_readed += part_length as i64;
            part_offset = 0;
        }

        // debug!("read end");

        Ok(())
    }
}

#[async_trait::async_trait]
impl StorageAPI for SetDisks {
    async fn list_bucket(&self, _opts: &BucketOptions) -> Result<Vec<BucketInfo>> {
        unimplemented!()
    }
    async fn make_bucket(&self, _bucket: &str, _opts: &MakeBucketOptions) -> Result<()> {
        unimplemented!()
    }

    async fn get_bucket_info(&self, _bucket: &str, _opts: &BucketOptions) -> Result<BucketInfo> {
        unimplemented!()
    }
    async fn get_object_info(&self, bucket: &str, object: &str, opts: &ObjectOptions) -> Result<ObjectInfo> {
        let (fi, _) = self.get_object_fileinfo(bucket, object, opts, false).await?;

        let oi = fi.into_object_info(bucket, object, false);

        Ok(oi)
    }
    async fn get_object_reader(
        &self,
        bucket: &str,
        object: &str,
        _rs: HTTPRangeSpec,
        _h: HeaderMap,
        opts: &ObjectOptions,
    ) -> Result<GetObjectReader> {
        let (fi, files) = self.get_object_fileinfo(bucket, object, opts, false).await?;

        let object_info = fi.into_object_info(bucket, object, false);

        debug!("get_object_reader {} object_info:{:?}", object, object_info);

        if object_info.deleted {
            return Err(Error::new(DiskError::FileNotFound));
        }

        // if object_info.size == 0 {
        //     let empty_rd: Box<dyn AsyncRead> = Box::new(Bytes::new());

        //     return Ok(GetObjectReader {
        //         stream: empty_rd,
        //         object_info,
        //     });
        // }

        let rs = HTTPRangeSpec::from_object_info(&object_info, opts.part_number);
        let (offset, length) = rs.get_offset_length(object_info.size.try_into().unwrap())?;

        debug!("get_object_reader offset:{}, length:{}", offset, length);

        let (rd, mut wd) = tokio::io::duplex(fi.erasure.block_size);
        let disks = self.disks.clone();
        let bucket = String::from(bucket);
        let object = String::from(object);
        tokio::spawn(async move {
            if let Err(e) = Self::get_object_with_fileinfo(&bucket, &object, offset, length, &mut wd, fi, files, &disks).await {
                debug!("get_object_with_fileinfo err {:?}", e);
            };
        });

        let read_stream = tokio_util::io::ReaderStream::new(rd);

        // let rd: Box<dyn AsyncRead> = Box::new(rd);

        let reader = GetObjectReader {
            stream: StreamingBlob::wrap(read_stream),
            object_info,
        };
        Ok(reader)
    }
    async fn put_object(&self, bucket: &str, object: &str, data: PutObjReader, opts: &ObjectOptions) -> Result<()> {
        let disks = self.disks.clone();

        let mut parity_drives = self.parity_count;
        if opts.max_parity {
            parity_drives = disks.len() / 2;
        }

        let data_drives = disks.len() - parity_drives;
        let mut write_quorum = data_drives;
        if data_drives == parity_drives {
            write_quorum += 1
        }

        let mut fi = FileInfo::new([bucket, object].join("/").as_str(), data_drives, parity_drives);

        debug!("put_object fi {:?}", fi);

        fi.data_dir = Uuid::new_v4();

        let parts_metadata = vec![fi.clone(); disks.len()];

        let (shuffle_disks, mut shuffle_parts_metadata) = Self::shuffle_disks_and_parts_metadata(&disks, &parts_metadata, &fi);

        let mut writers = Vec::with_capacity(shuffle_disks.len());

        let tmp_dir = Uuid::new_v4().to_string();

        let tmp_object = format!("{}/{}/part.1", tmp_dir, fi.data_dir);

        for disk in shuffle_disks.iter() {
            let disk = disk.as_ref().unwrap().clone();

            let writer = disk
                .create_file("", RUSTFS_META_TMP_BUCKET, &tmp_object, data.content_length)
                .await?;

            writers.push(writer);
        }

        // let mut futures = Vec::with_capacity(disks.len());

        // let mut errors = Vec::with_capacity(shuffle_disks.len());

        // for disk in shuffle_disks.iter() {
        //     if disk.is_none() {
        //         errors.push(Some(Error::new(DiskError::DiskNotFound)));
        //         continue;
        //     }

        //     let (reader, writer) = tokio::io::duplex(fi.erasure.block_size);

        //     let disk = disk.as_ref().unwrap().clone();
        //     let tmp_object = tmp_object.clone();

        //     // TODO: save small file in fileinfo.data instead of write file;

        //     futures.push(async move {
        //         disk.create_file("", RUSTFS_META_TMP_BUCKET, tmp_object.as_str(), data.content_length, reader)
        //             .await
        //     });
        //     // futures.push(tokio::spawn(async move {
        //     //     debug!("do createfile");
        //     //     disk.CreateFile("", bucket.as_str(), object.as_str(), data.content_length, reader)
        //     //         .await;
        //     // }));

        //     writers.push(writer);
        // }

        let erasure = Erasure::new(fi.erasure.data_blocks, fi.erasure.parity_blocks, fi.erasure.block_size);

        let w_size = erasure
            .encode(data.stream, &mut writers, data.content_length, write_quorum)
            .await?;

        // debug!("encode content_length: {}, total write {}", data.content_length, w_size);

        // // close reader in create_file
        // drop(writers);

        // let results = join_all(futures).await;
        // for result in results {
        //     match result {
        //         Ok(_) => {
        //             errors.push(None);
        //         }
        //         Err(e) => {
        //             errors.push(Some(e));
        //         }
        //     }
        // }

        // debug!("CreateFile errs:{:?}", errors);

        // TODO: reduceWriteQuorumErrs
        // evalDisks

        for fi in shuffle_parts_metadata.iter_mut() {
            fi.mod_time = Some(OffsetDateTime::now_utc());
            fi.size = w_size;
            fi.add_object_part(1, w_size, fi.mod_time, w_size);

            debug!("put_object fi {:?}", &fi)
        }

        let (rename_ress, rename_errs) = Self::rename_data(
            &shuffle_disks,
            RUSTFS_META_TMP_BUCKET,
            tmp_dir.as_str(),
            &shuffle_parts_metadata,
            bucket,
            object,
        )
        .await;

        // TODO: reduceWriteQuorumErrs

        warn!("put_object rename_errs:{:?}", &rename_errs);

        // TODO: reduce_common_data_dir
        if let Some(old_dir) = rename_ress
            .iter()
            .filter_map(|v| if v.is_some() { v.as_ref().unwrap().old_data_dir } else { None })
            .map(|v| v.to_string())
            .next()
        {
            let cm_errs = self.commit_rename_data_dir(&shuffle_disks, &bucket, &object, &old_dir).await;
            warn!("put_object commit_rename_data_dir:{:?}", &cm_errs);
        }

        self.delete_all(RUSTFS_META_TMP_BUCKET, &tmp_dir).await?;

        // TODO:返回objectInfo
        Ok(())
    }

    async fn put_object_part(
        &self,
        bucket: &str,
        object: &str,
        upload_id: &str,
        part_id: usize,
        data: PutObjReader,
        _opts: &ObjectOptions,
    ) -> Result<PartInfo> {
        let upload_id_path = Self::get_upload_id_dir(bucket, object, upload_id);

        let (mut fi, _) = self.check_upload_id_exists(bucket, object, upload_id, true).await?;

        let write_quorum = fi.write_quorum(self.default_write_quorum());

        let disks = self.disks.clone();
        let disks = Self::shuffle_disks(&disks, &fi.erasure.distribution);

        let part_suffix = format!("part.{}", part_id);
        let tmp_part = format!("{}x{}", Uuid::new_v4(), OffsetDateTime::now_utc().unix_timestamp());
        let tmp_part_path = format!("{}/{}", tmp_part, part_suffix);

        let mut writers = Vec::with_capacity(disks.len());

        for disk in disks.iter() {
            let disk = disk.as_ref().unwrap().clone();

            let writer = disk.append_file(RUSTFS_META_TMP_BUCKET, &tmp_part_path).await?;

            writers.push(writer);
        }

        let erasure = Erasure::new(fi.erasure.data_blocks, fi.erasure.parity_blocks, fi.erasure.block_size);

        let w_size = erasure
            .encode(data.stream, &mut writers, data.content_length, write_quorum)
            .await?;

        // debug!(
        //     "put_object_part encode write {} total: {} for {:?}",
        //     w_size, data.content_length, &tmp_part_path
        // );

        let part_path = format!("{}/{}/{}", upload_id_path, fi.data_dir, part_suffix);
        let errs =
            Self::rename_part(&disks, RUSTFS_META_TMP_BUCKET, &tmp_part_path, RUSTFS_META_MULTIPART_BUCKET, &part_path).await;

        warn!("rename_part: {:?}", errs);

        let part_info = ObjectPartInfo {
            number: part_id,
            size: w_size,
            mod_time: Some(OffsetDateTime::now_utc()),
            actual_size: data.content_length,
        };

        // debug!("put_object_part part_info {:?}", part_info);

        fi.parts = vec![part_info];

        let fi_buff = fi.marshal_msg()?;

        let errs = Self::write_all(&disks, RUSTFS_META_MULTIPART_BUCKET, format!("{}.meta", &part_path).as_str(), fi_buff).await;

        warn!("write_all: {:?}", errs);

        let ret = PartInfo {
            part_num: part_id,
            last_mod: Some(OffsetDateTime::now_utc()),
            size: w_size,
        };

        Ok(ret)
    }

    async fn new_multipart_upload(&self, bucket: &str, object: &str, opts: &ObjectOptions) -> Result<MultipartUploadResult> {
        let disks = self.disks.clone();

        let mut parity_drives = self.parity_count;
        if opts.max_parity {
            parity_drives = disks.len() / 2;
        }

        let data_drives = disks.len() - parity_drives;
        let mut write_quorum = data_drives;
        if data_drives == parity_drives {
            write_quorum += 1
        }

        let _ = write_quorum;

        let mut fi = FileInfo::new([bucket, object].join("/").as_str(), data_drives, parity_drives);

        fi.data_dir = Uuid::new_v4();
        fi.fresh = true;

        let parts_metadata = vec![fi.clone(); disks.len()];

        let (shuffle_disks, mut shuffle_parts_metadata) = Self::shuffle_disks_and_parts_metadata(&disks, &parts_metadata, &fi);

        let now: OffsetDateTime = OffsetDateTime::now_utc();
        for fi in shuffle_parts_metadata.iter_mut() {
            fi.mod_time = Some(now);
        }

        fi.mod_time = Some(now);

        let upload_uuid = format!("{}x{}", Uuid::new_v4(), fi.mod_time.unwrap().unix_timestamp());

        let upload_id = base64_encode(format!("{}.{}", "globalDeploymentID", upload_uuid).as_bytes());

        let upload_path = Self::get_upload_id_dir(bucket, object, upload_uuid.as_str());

        let errs = Self::write_unique_file_info(
            &shuffle_disks,
            bucket,
            RUSTFS_META_MULTIPART_BUCKET,
            upload_path.as_str(),
            &shuffle_parts_metadata,
        )
        .await;

        warn!("write_unique_file_info errs :{:?}", &errs);
        // TODO: reduceWriteQuorumErrs
        // evalDisks

        Ok(MultipartUploadResult { upload_id })
    }
    async fn abort_multipart_upload(&self, bucket: &str, object: &str, upload_id: &str, _opts: &ObjectOptions) -> Result<()> {
        self.check_upload_id_exists(bucket, object, upload_id, false).await?;
        let upload_id_path = Self::get_upload_id_dir(bucket, object, upload_id);

        self.delete_all(RUSTFS_META_MULTIPART_BUCKET, &upload_id_path).await
    }
    // complete_multipart_upload 完成
    // #[tracing::instrument(skip(self))]
    async fn complete_multipart_upload(
        &self,
        bucket: &str,
        object: &str,
        upload_id: &str,
        uploaded_parts: Vec<CompletePart>,
        opts: &ObjectOptions,
    ) -> Result<ObjectInfo> {
        let (mut fi, files_metas) = self.check_upload_id_exists(bucket, object, upload_id, true).await?;
        let upload_id_path = Self::get_upload_id_dir(bucket, object, upload_id);

        let write_quorum = fi.write_quorum(self.default_write_quorum());

        let disks = self.disks.clone();
        // let disks = Self::shuffle_disks(&disks, &fi.erasure.distribution);

        let part_path = format!("{}/{}/", upload_id_path, fi.data_dir);

        let files: Vec<String> = uploaded_parts.iter().map(|v| format!("part.{}.meta", v.part_num)).collect();

        // readMultipleFiles

        let req = ReadMultipleReq {
            bucket: RUSTFS_META_MULTIPART_BUCKET.to_string(),
            prefix: part_path,
            files,
            max_size: 1 << 20,
            metadata_only: true,
            abort404: true,
            max_results: 0,
        };

        let part_files_resp = Self::read_multiple_files(&disks, req, write_quorum).await;

        if part_files_resp.len() != uploaded_parts.len() {
            return Err(Error::msg("part result number err"));
        }

        for (i, res) in part_files_resp.iter().enumerate() {
            let part_id = uploaded_parts[i].part_num;
            if !res.error.is_empty() || !res.exists {
                return Err(Error::new(ErasureError::InvalidPart(part_id)));
            }

            let part_fi = FileInfo::unmarshal(&res.data).map_err(|_| Error::new(ErasureError::InvalidPart(part_id)))?;
            let part = &part_fi.parts[0];
            let part_num = part.number;

            // debug!("complete part {} file info {:?}", part_num, &part_fi);
            // debug!("complete part {} object info {:?}", part_num, &part);

            if part_id != part_num {
                return Err(Error::new(ErasureError::InvalidPart(part_id)));
            }

            fi.add_object_part(part.number, part.size, part.mod_time, part.actual_size);
        }

        let (shuffle_disks, mut parts_metadatas) = Self::shuffle_disks_and_parts_metadata_by_index(&disks, &files_metas, &fi);

        let curr_fi = fi.clone();

        fi.parts = Vec::with_capacity(uploaded_parts.len());

        let mut total_size: usize = 0;

        for (i, p) in uploaded_parts.iter().enumerate() {
            let has_part = curr_fi.parts.iter().find(|v| v.number == p.part_num);
            if has_part.is_none() {
                return Err(Error::new(ErasureError::InvalidPart(p.part_num)));
            }

            let ext_part = &curr_fi.parts[i];

            // TODO: crypto

            total_size += ext_part.size;

            fi.parts.push(ObjectPartInfo {
                number: p.part_num,
                size: ext_part.size,
                mod_time: ext_part.mod_time,
                actual_size: ext_part.actual_size,
            });
        }

        fi.size = total_size;
        fi.mod_time = opts.mod_time;
        if fi.mod_time.is_none() {
            fi.mod_time = Some(OffsetDateTime::now_utc());
        }

        for meta in parts_metadatas.iter_mut() {
            if meta.is_valid() {
                meta.size = fi.size;
                meta.mod_time = fi.mod_time;
                meta.parts = fi.parts.clone();
            }
        }

        for p in curr_fi.parts.iter() {
            self.remove_part_meta(bucket, object, upload_id, curr_fi.data_dir.to_string().as_str(), p.number)
                .await?;

            if !fi.parts.iter().any(|v| v.number == p.number) {
                self.remove_object_part(bucket, object, upload_id, curr_fi.data_dir.to_string().as_str(), p.number)
                    .await?;
            }
        }

        let (rename_ress, rename_errs) = Self::rename_data(
            &shuffle_disks,
            RUSTFS_META_MULTIPART_BUCKET,
            &upload_id_path,
            &parts_metadatas,
            bucket,
            object,
        )
        .await;

        fi.is_latest = true;

        warn!("rename_data errs {:?}", &rename_errs);
        // debug!("complete fileinfo {:?}", &fi);

        // TODO: reduce_common_data_dir
        if let Some(old_dir) = rename_ress
            .iter()
            .filter_map(|v| if v.is_some() { v.as_ref().unwrap().old_data_dir } else { None })
            .map(|v| v.to_string())
            .next()
        {
            let cm_errs = self.commit_rename_data_dir(&shuffle_disks, &bucket, &object, &old_dir).await;
            warn!("put_object commit_rename_data_dir:{:?}", &cm_errs);
        }

        let _ = self.delete_all(RUSTFS_META_MULTIPART_BUCKET, &upload_id_path).await;

        Ok(fi.into_object_info(bucket, object, false))
    }

    async fn delete_bucket(&self, _bucket: &str) -> Result<()> {
        unimplemented!()
    }
}
